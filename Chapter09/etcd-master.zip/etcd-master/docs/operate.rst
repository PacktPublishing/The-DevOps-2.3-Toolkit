.. _operate:


Monitor
#######

TODO


List of metrics
###############

Latest
======

Download: :download:`latest <metrics/latest>`.

.. literalinclude:: metrics/latest
  :language: BASH

v3.3
====

- :download:`v3.3.9 <metrics/v3.3.9>`
- :download:`v3.3.8 <metrics/v3.3.8>`
- :download:`v3.3.7 <metrics/v3.3.7>`
- :download:`v3.3.6 <metrics/v3.3.6>`
- :download:`v3.3.5 <metrics/v3.3.5>`
- :download:`v3.3.4 <metrics/v3.3.4>`
- :download:`v3.3.3 <metrics/v3.3.3>`
- :download:`v3.3.2 <metrics/v3.3.2>`
- :download:`v3.3.1 <metrics/v3.3.1>`
- :download:`v3.3.0 <metrics/v3.3.0>`

.. literalinclude:: metrics/v3.3.9
  :language: BASH

v3.2
====

- :download:`v3.2.24 <metrics/v3.2.24>`
- :download:`v3.2.23 <metrics/v3.2.23>`
- :download:`v3.2.22 <metrics/v3.2.22>`
- :download:`v3.2.21 <metrics/v3.2.21>`
- :download:`v3.2.20 <metrics/v3.2.20>`
- :download:`v3.2.19 <metrics/v3.2.19>`
- :download:`v3.2.18 <metrics/v3.2.18>`
- :download:`v3.2.17 <metrics/v3.2.17>`
- :download:`v3.2.16 <metrics/v3.2.16>`
- :download:`v3.2.15 <metrics/v3.2.15>`
- :download:`v3.2.14 <metrics/v3.2.14>`
- :download:`v3.2.13 <metrics/v3.2.13>`
- :download:`v3.2.12 <metrics/v3.2.12>`
- :download:`v3.2.11 <metrics/v3.2.11>`
- :download:`v3.2.10 <metrics/v3.2.10>`
- :download:`v3.2.9 <metrics/v3.2.9>`
- :download:`v3.2.8 <metrics/v3.2.8>`
- :download:`v3.2.7 <metrics/v3.2.7>`
- :download:`v3.2.6 <metrics/v3.2.6>`
- :download:`v3.2.5 <metrics/v3.2.5>`
- :download:`v3.2.4 <metrics/v3.2.4>`
- :download:`v3.2.3 <metrics/v3.2.3>`
- :download:`v3.2.2 <metrics/v3.2.2>`
- :download:`v3.2.1 <metrics/v3.2.1>`
- :download:`v3.2.0 <metrics/v3.2.0>`

.. literalinclude:: metrics/v3.2.24
  :language: BASH

v3.1
====

- :download:`v3.1.19 <metrics/v3.1.19>`
- :download:`v3.1.18 <metrics/v3.1.18>`
- :download:`v3.1.17 <metrics/v3.1.17>`
- :download:`v3.1.16 <metrics/v3.1.16>`
- :download:`v3.1.15 <metrics/v3.1.15>`
- :download:`v3.1.14 <metrics/v3.1.14>`
- :download:`v3.1.13 <metrics/v3.1.13>`
- :download:`v3.1.12 <metrics/v3.1.12>`
- :download:`v3.1.11 <metrics/v3.1.11>`
- :download:`v3.1.10 <metrics/v3.1.10>`
- :download:`v3.1.9 <metrics/v3.1.9>`
- :download:`v3.1.8 <metrics/v3.1.8>`
- :download:`v3.1.7 <metrics/v3.1.7>`
- :download:`v3.1.6 <metrics/v3.1.6>`
- :download:`v3.1.5 <metrics/v3.1.5>`
- :download:`v3.1.4 <metrics/v3.1.4>`
- :download:`v3.1.3 <metrics/v3.1.3>`
- :download:`v3.1.2 <metrics/v3.1.2>`
- :download:`v3.1.1 <metrics/v3.1.1>`
- :download:`v3.1.0 <metrics/v3.1.0>`

.. literalinclude:: metrics/v3.1.19
  :language: BASH
