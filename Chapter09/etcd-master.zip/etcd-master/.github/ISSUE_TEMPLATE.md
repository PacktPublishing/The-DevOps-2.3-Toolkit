
Please read https://github.com/etcd-io/etcd/blob/master/Documentation/reporting_bugs.md.
