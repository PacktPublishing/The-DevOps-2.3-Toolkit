kops delete cluster \
  --name $NAME \
  --yes
