> NOTICE: The code for weave-kube has been merged into the [Weave
> Net](https://github.com/weaveworks/weave) repository; if you have
> any issues, please file them there.

To install Weave on Kubernetes, run:
```bash
kubectl apply -f https://git.io/weave-kube
```
