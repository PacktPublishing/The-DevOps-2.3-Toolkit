# Legacy Specs

This is a duplicate of the romana-kubeadm.yml from ../../docs/kubernetes so that links/instructions from
https://kubernetes.io/docs/setup/independent/create-cluster-kubeadm/#pod-network continue working.
Once the documentation links are updated, this can be removed.
