package networking

var Version = ""
var GitVersion = ""
